package com.felipegama.domain;

public class Categoria {
	private Long idCategoria;
	private String descricao;

	public Long getIdCategoria() {
		return idCategoria;
	}

	public void setIdCategoia(Long idCategoria) {
		this.idCategoria = idCategoria;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

}
